## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(simplexity)
library(codaredistlm)

## ----load---------------------------------------------------------------------
suppressPackageStartupMessages({library(dplyr)}) # for piping and tibbles etc
data(fairclough) # load data into session from codaredistlm package

## ----help, eval = FALSE-------------------------------------------------------
# ?fairclough

## ----mold---------------------------------------------------------------------
# get just the compositions we are interested in
fc_comp <- 
  fairclough %>%
  mutate(lmvpa = lpa + mpa + vpa) %>%
  select(sed, lmvpa, sleep) %>%
  as_tibble()

# have a peek
head(fc_comp)

# check what rows sum to
table(rowSums(fc_comp)) # all approx 1440 minutes of the day

# could do this to make exactly equal to 1440 (but overkill)
# rsms <- rowSums(fc_comp)
# fc_comp <- 1440 * apply(fc_comp, 2, function(x) x / rsms) 

## ----charise1-----------------------------------------------------------------
summary(fc_comp)

## ----niave--------------------------------------------------------------------
grid_combos <-
  expand.grid(
    sed   = seq(300, 690, 10), 
    lmvpa = seq(220, 580, 10), 
    sleep = seq(400, 620, 10)
  )
nrow(grid_combos)
# safe way to get rows adding up to 1440 within rounding tolerance
correct_sums <- abs(rowSums(grid_combos) - 1440) < 1e-6
sum(correct_sums) # the number of rows that should remain
grid_combos <- grid_combos[correct_sums, ] # just keep 1440 min rows
nrow(grid_combos)
tail(grid_combos) # look at last 6 rows

## ----plot_niave, fig.width=8, fig.height=4------------------------------------
suppressPackageStartupMessages({library(compositions)})
old_mfrow <- if (is.null(par("mfrow"))) c(1, 1) else par("mfrow")
par(mfrow = c(1, 2))
plot(acomp(fc_comp), col = add_alpha("dodgerblue", 0.3), pch = 16, pca = TRUE)
legend(
  x = 0.6, y = 0.85, 
  legend = c("Fairclough\ndata", "Niave grid\nin S^3"), 
  pch = 16, 
  col = c("dodgerblue", "orange"),
  cex = 0.7
  # bty = "n"
)
plot(acomp(grid_combos), col = add_alpha("orange", 0.3), pch = 16, pca = TRUE)
par(mfrow = old_mfrow) # return device to as was before

## ----latt1--------------------------------------------------------------------
# note that the "L" after the number tells R to make it integer type (not numeric)
D <- 3L; spacing <- 10L; n_chunks <- 1440L / spacing;
S3_10m_lattice <- spacing * enumerate_simplex(D, n = n_chunks)
head(S3_10m_lattice)

# OR if the closure value is 1 then use
# S3_10m_lattice <- enumerate_simplex(D, n = n_chunks) / n_chunks

## ----latt2--------------------------------------------------------------------
D <- 3L; spacing <- 10L; n_chunks <- 1440L / spacing;
S3_10m_lattice <- spacing * (enumerate_simplex(D, n = n_chunks - D) + 1L)
head(S3_10m_lattice)
nrow(S3_10m_lattice)

# long way if you want to check
latt_with_0 <- spacing * enumerate_simplex(D, n = n_chunks)
print(c(class(latt_with_0), class(latt_with_0[1, ]))) # matrix of integers
latt_0_rows <- apply(latt_with_0 == 0L, 1, any) # by row, if any 0, then 0 in row
head(latt_with_0[!latt_0_rows, ])  # remove rows with 0s, looks the same with more steps!
sum(!latt_0_rows) # same as nrow(S3_10m_lattice)?

